'use strict';

angular.module('app.transcripts', ['app.core', 'ngFileUpload'])
  .run(function () {

  });

'use strict';

angular.module('app.transcripts').config(function ($stateProvider) {
  $stateProvider
    .state('app.transcripts', {
      url: '/transcripts',
      views: {
        pageContent: {
          templateUrl: 'transcripts/views/transcripts.html',
          controller: 'TranscriptsCtrl as transcripts',
          resolve: {
            transcripts: function (profile, Transcript) {
              return Transcript.findAll({
                where: {
                  profile_id: {
                    '==': profile.id
                  }
                }
              })
            }
          }
        }
      }
    })
});

'use strict';

angular.module('app.transcripts').controller('TranscriptsCtrl', function (transcripts, $ionicPopup, Config) {
  this.data = transcripts;

  this.add = function () {
    $ionicPopup.alert({
      title: 'Sending Transcript',
      template: 'Official transcripts are required in order to tutor other students. Please send official transcripts to the address below<br/><br/>' + Config.ENV.PHYSICAL_ADDRESS
    });
  }
});

'use strict';

angular.module('app.session', ['app.core'])
  .run(function (SideMenu) {
    SideMenu.add('Session History', 'app.session', 'ion-clock', 3);

  });

'use strict';

angular.module('app.profile', ['app.core', 'ngFileUpload'])
  .run(function (SideMenu) {
    SideMenu.add('Profile', 'app.profile', 'ion-person', 1);
  });

'use strict';

angular.module('app.profile').config(function ($stateProvider) {
  $stateProvider
    .state('app.profile', {
      url: '/profile',
      views: {
        'pageContent': {
          templateUrl: 'profile/views/profile.html',
          controller: 'ProfileCtrl as profile'
        }
      }
    })
    .state('app.profile_edit_name', {
      url: '/profile_edit_name',
      views: {
        'pageContent': {
          templateUrl: 'profile/views/edit_name.html',
          controller: 'ProfileCtrl as profile'
        }
      }
    })
    .state('app.profile_edit_picture', {
      url: '/edit_picture',
      views: {
        'pageContent': {
          templateUrl: 'profile/views/edit_picture.html',
          controller: 'ProfileCtrl as profile'
        }
      }
    })
    .state('app.profile_edit_phone', {
      url: '/profile_edit_phone',
      views: {
        'pageContent': {
          templateUrl: 'profile/views/edit_phone.html',
          controller: 'ProfileCtrl as profile'
        }
      }
    })
    .state('app.profile_edit_school', {
      url: '/profile_edit_school',
      views: {
        'pageContent': {
          templateUrl: 'profile/views/edit_school.html',
          controller: 'ProfileCtrl as profile'
        }
      }
    })
});

'use strict';

angular.module('app.profile').value('ProfileFields',
  {
    name: [
      {
        key: 'first_name',
        type: 'floating-input',
        templateOptions: {
          type: 'text',
          label: 'First Name',
          required: true,
          placeholder: 'First Name'
        }
      },
      {
        key: 'last_name',
        type: 'floating-input',
        templateOptions: {
          type: 'text',
          label: 'Last Name',
          required: true,
          placeholder: 'Last Name'
        }
      }
    ],
    phone: [
      {
        key: 'phone_number',
        type: 'floating-input',
        templateOptions: {
          type: 'text',
          label: 'Phone Number',
          required: true,
          placeholder: 'Phone Number'
        }
      }
    ],
    school: [
      {
        key: 'school',
        type: 'select',
        templateOptions: {
          label: "Select School",
          options: [],
          valueProp: 'id',
          labelProp: 'name'
        },
        controller: function ($scope, School) {
          return School.findAll().then(function (schools) {
            $scope.to.options = schools;
          });
        }
      }
    ]
  }
);

'use strict';

angular.module('app.profile').controller('ProfileCtrl', function ($scope, $stamplay, $ionicPopup, $ionicLoading, Profile, profile, schools, ProfileFields) {
  var vm = this;

  // Data
  this.data = profile;
  this.fields = ProfileFields;
  this.schools = schools;

  this.save = function (profile) {
    $ionicLoading.show();
    profile.DSSave().then(function (res) {
      $ionicLoading.hide();
      $ionicPopup.alert({
        title: 'Profile saved',
        template: ''
      });
    }).catch(function (err) {
      $ionicLoading.hide();
    });
  };

  this.test = function (file) {
    Profile.updateProfilePicture(file);
  }
});

'use strict';

angular.module('app.payment', ['app.core'])
  .run(function (SideMenu) {
    SideMenu.add('Payment', 'app.payment', 'ion-card', 2);
  });

'use strict';

angular.module('app.payment').config(function ($stateProvider) {
  $stateProvider
    .state('app.payment', {
      url: '/payment',
      views: {
        'pageContent': {
          templateUrl: 'payment/views/payment.html',
          controller: 'PaymentCtrl as payment',
          resolve: {
            card: function (profile, Profile) {
              return Profile.getCard(profile.user_id);
            }
          }
        }
      }
    })
});

'use strict';

angular.module('app.payment').value('PaymentFields',
  {
    card: [
      {
        key: 'name',
        type: 'floating-input',
        templateOptions: {
          type: 'text',
          label: 'Name on Card',
          required: true,
          placeholder: 'Name on Card'
        }
      },
      {
        key: 'number',
        type: 'floating-input',
        templateOptions: {
          type: 'number',
          label: 'Card Number',
          required: true,
          placeholder: 'Card Number'
        }
      },
      {
        key: 'exp_month',
        type: 'floating-input',
        templateOptions: {
          type: 'text',
          label: 'Expiration Month',
          required: true,
          placeholder: 'Expiration Month'
        }
      }, {
        key: 'exp_year',
        type: 'floating-input',
        templateOptions: {
          type: 'text',
          label: 'Expiration Year',
          required: true,
          placeholder: 'Expiration Year'
        }
      }, {
        key: 'cvc',
        type: 'floating-input',
        templateOptions: {
          type: 'password',
          label: 'CVC',
          required: true,
          placeholder: 'CVC'
        }
      }
    ]
  }
);

'use strict';

angular.module('app.payment').controller('PaymentCtrl', function ($state, Payment, PaymentFields, DSStamplayAdapter, $ionicPopup, profile, stripe, card) {
  var vm = this;
  this.fields = PaymentFields;
  this.card = card;
  this.stamplay = DSStamplayAdapter.getService();

  this.isUpdatingCard = _.isUndefined(card);

  // var token = stripe.create
  // Payment.charge(profile.user_id, card.card_id, 10.00, 'USD').then(function (res) {
  //   // debugger;
  // }).catch(function (err) {
  //   // debugger;
  // });

  this.addCard = function (card) {
    card.exp_month = moment(card.expiration).format('M');
    card.exp_year = moment(card.expiration).format('YY');

    delete card.expiration;

    stripe.card.createToken(card).then(function (response) {
      Payment.addCard(profile, user_id, response.id).then(function (res) {

      });
      vm.stamplay.Stripe.createCreditCard(profile.user_id, response.id).then(function (res) {
        $ionicPopup.alert({
          title: 'Credit card added',
          template: 'You can now reserve time with tutors'
        });
        $state.go('app.dashboard');
      }).catch(function (err) {
        $ionicPopup.alert({
          title: 'Error'
        })
      })
    }).catch(function (error) {
    });
  }
});

'use strict';
angular.module('main', [])
  .config(function () {
    //$stateProvider
    //// this state is placed in the <ion-nav-view> in the index.html
    //  .state('main', {
    //    url: '/main',
    //    abstract: true,
    //    templateUrl: 'main/templates/menu.html',
    //    controller: 'MenuCtrl as menu'
    //  })
    //  .state('main.list', {
    //    url: '/list',
    //    views: {
    //      'pageContent': {
    //        templateUrl: 'main/templates/list.html',
    //        // controller: '<someCtrl> as ctrl'
    //      }
    //    }
    //  })
    //  .state('main.listDetail', {
    //    url: '/list/detail',
    //    views: {
    //      'pageContent': {
    //        templateUrl: 'main/templates/list-detail.html',
    //        // controller: '<someCtrl> as ctrl'
    //      }
    //    }
    //  })
    //  .state('main.debug', {
    //    url: '/debug',
    //    views: {
    //      'pageContent': {
    //        templateUrl: 'main/templates/debug.html',
    //        controller: 'DebugCtrl as ctrl'
    //      }
    //    }
    //  });
  });

'use strict';
angular.module('main')
.service('Main', function ($log, $timeout) {

  $log.log('Hello from your Service: Main in module main');

  // some initial data
  this.someData = {
    binding: 'Yes! Got that databinding working'
  };

  this.changeBriefly = function () {
    var initialValue = this.someData.binding;
    this.someData.binding = 'Yeah this was changed';

    var that = this;
    $timeout(function () {
      that.someData.binding = initialValue;
    }, 500);
  };

});

'use strict';
angular.module('main')
.controller('MenuCtrl', function ($log) {

  $log.log('Hello from your Controller: MenuCtrl in module main:. This is your controller:', this);

});

'use strict';
angular.module('main')
.controller('DebugCtrl', function ($log, Main, Config, $cordovaDevice) {

  $log.log('Hello from your Controller: DebugCtrl in module main:. This is your controller:', this);

  // bind data from services
  this.someData = Main.someData;
  this.ENV = Config.ENV;
  this.BUILD = Config.BUILD;
  // get device info
  ionic.Platform.ready(function () {
    if (ionic.Platform.isWebView()) {
      this.device = $cordovaDevice.getDevice();
    }
  }.bind(this));

  // PASSWORD EXAMPLE
  this.password = {
    input: '', // by user
    strength: ''
  };
  this.grade = function () {
    var size = this.password.input.length;
    if (size > 8) {
      this.password.strength = 'strong';
    } else if (size > 3) {
      this.password.strength = 'medium';
    } else {
      this.password.strength = 'weak';
    }
  };
  this.grade();

});

'use strict';

angular.module('app.dash', ['app.core'])
  .run(function ($rootScope, SideMenu, $ionicPlatform) {

    // Add sidemenu
    // SideMenu.add('Dashboard', 'app.dash', 'ion-speedometer', 0);

    // Setup needed cordova plugins
    $ionicPlatform.ready(function () {

    });
  });

'use strict';

angular.module('app.dash')
  .config(function ($stateProvider) {
    $stateProvider
      .state('app.dash', {
        url: '/dash',
        views: {
          pageContent: {
            templateUrl: 'dash/views/dash.html',
            controller: 'DashCtrl as dash',
            resolve: {
              geo: function ($cordovaGeolocation) {
                return $cordovaGeolocation.getCurrentPosition({timeout: 10000, enableHighAccuracy: true});
              }
            }
          }
        }
      })
      .state('app.dash.tutor', {
        url: '/tutor',
        templateUrl: 'dash/views/tutor.html',
        controller: 'TutorDashCtrl as tutorDash'
      })
      .state('app.dash.student', {
        url: '/student',
        templateUrl: 'dash/views/student.html',
        controller: 'StudentDashCtrl as studentDash',
        resolve: {
          tutors: function (Profile) {
            return Profile.findAll({
              where: {
                isAvailable: {
                  '==': true
                }
              }
            })
          }
        }
      });
  });

'use strict';

angular.module('app.dash').controller('TutorDashCtrl', function ($scope, $interval, $timeout, $ionicModal, $ionicPopup, Utilities, PusherInstance, ENUM, profile, Session) {
  var vm, _handshakeTimer, _sessionTimer, _modal, _requestPopup;

  vm = this;

  this.sessionLength = 0;

  this.startSession = function (session) {
    session.state = ENUM.SESSION.IN_PROGRESS;
    session.start = moment();
    session.end = moment();
    updateSessionTimer(session.start, session.end);
    session.DSSave().then(function (session) {
      $scope.dash.session = session;
      _sessionTimer = $interval(function () {
        session.end = moment();
        updateSessionTimer(session.start, session.end);
      }, 1000)
    });
  };

  this.endSession = function (session) {
    session.end = moment();
    session.state = ENUM.SESSION.FINISHED;
    session.DSSave().then(function (session) {
      $scope.dash.session = session;
    });
    $interval.cancel(_sessionTimer);
  };

  this.rateSession = function (session) {
    session.state = ENUM.SESSION.FINISHED;
    session.DSSave().then(function () {
      $scope.dash.session = Session.createInstance({});
      _modal.hide().then(function () {
        _modal.remove();
      })
    })
  };

  // Pusher events
  PusherInstance.subscribe('session').bind('new', function (session) {
    Session.find(session.id).then(function (session) {
      session.DSLoadRelations(['profile', 'location', 'course']).then(function (session) {
        // Only consider sessions from the same university as tutor
        if (session.location.school.id === profile.school.id) {
          // Temporarily reserve this session to this tutor
          session.state = ENUM.SESSION.AWAITING_HAND_SHAKE;
          session.DSSave().then(function (temporary_reservation_session) {
            $scope.dash.session = temporary_reservation_session;
            _handshakeTimer = $timeout(requestTimeout, 15000);
            _requestPopup = $ionicPopup.confirm({
              title: 'Tutoring Request',
              scope: $scope,
              templateUrl: 'dash/views/modals/tutorConfirmSession.html',
              buttons: [
                {
                  text: 'Reject',
                  type: 'button-assertive',
                  onTap: function () {
                    return false;
                  }
                }, {
                  text: 'Accept',
                  type: 'button-balanced',
                  onTap: function () {
                    return true;
                  }
                }
              ]
            });

            _requestPopup.then(function (accepted) {
              if (accepted) {
                $timeout.cancel(_handshakeTimer);
                $scope.dash.session.state = ENUM.SESSION.PENDING_START;
                $scope.dash.session.tutor = profile;

                $scope.dash.session.DSSave().then(function (active_session) {
                  $scope.dash.session = active_session;

                  $ionicModal.fromTemplateUrl('dash/views/modals/tutorSession.html', {
                    scope: $scope,
                    animation: 'slide-in-up'
                  }).then(function (modal) {
                    _modal = modal;
                    modal.show();
                  })
                })
              }
            })
          });
        }
      });
    });
  });

  function requestTimeout() {
    _requestPopup.close();
    // Put the session back on the queue
    $scope.dash.session.state = ENUM.SESSION.PENDING;
    $scope.dash.session.DSSave().then(function () {
      $scope.dash.session = Session.createInstance();
      $ionicPopup.alert({
        title: 'Request expired',
        template: 'The tutoring request expired. Please disable <strong>Tutor Mode</strong> if you are not available to tutor'
      })
    });
  }

  function updateSessionTimer(start, end) {
    vm.sessionLength = Utilities.formatSessionTime(end.diff(moment(start), 'seconds'));
  }
});

'use strict';

angular.module('app.dash').controller('StudentDashCtrl', function ($scope, $ionicModal, PusherInstance, ENUM, profile, tutors, Location, Course, Session, Profile) {
    var vm, _modal;

    vm = this;
    _modal = '';

    this.tutors = tutors;
    this.locations = [];
    this.courses = [];

    $scope.dash.session.student_id = profile.id;

    this.selectLocation = function () {
      Location.findAll({
        where: {
          school_id: {
            '==': profile.school.id
          }
        }
      }).then(function (locations) {
        vm.locations = locations;
        createModal('selectLocation').then(function (modal) {
          modal.show();
        })
      });
    };

    this.selectCourse = function () {
      Course.findAll({
        where: {
          school_id: {
            '==': profile.school.id
          }
        }
      }).then(function (courses) {
        vm.courses = courses;
        createModal('selectCourse').then(function (modal) {
          modal.show();
        })
      })
    };

    this._closeModal = function () {
      _modal.hide().then(function () {
        _modal.remove();
      })
    };

    this.requestTutor = function (session) {
      session.state = ENUM.SESSION.PENDING;

      session.DSCreate().then(function (session) {
        $scope.dash.session = session;
      });

      createModal('studentSession').then(function (modal) {
        modal.show();
      })
    };

    this.cancelSession = function () {
      
    };

    function createModal(name) {
      return $ionicModal.fromTemplateUrl('dash/views/modals/' + name + '.html', {
        scope: $scope,
        animation: 'slide-in-up'
      }).then(function (modal) {
        _modal = modal;
        return modal;
      })
    }

    function updateTutors(tutors) {
      angular.extend($scope.dash.map.markers._user, {
        message: tutors.length + ' tutors near you!'
      });
      // Remove all current tutors and replace them with newly available ones
      for (var marker in $scope.dash.map.markers) {
        if (marker.includes('tutor')) {
          delete $scope.dash.map.markers[marker];
        }
      }
      _.forEach(tutors, function (tutor, index) {
        $scope.dash.map.markers['tutor_' + index] = {
          lat: tutor._geolocation.coordinates[1],
          lng: tutor._geolocation.coordinates[0],
          icon: {
            iconUrl: 'dash/assets/tutor.png',
            iconSize: [48, 48],
            iconAnchor: [48, 48]
          }
        }
      });
    }

    // Pusher events
    PusherInstance.subscribe('tutors').bind('availability_changed', function () {
      Profile.refreshAll({
        where: {
          isAvailable: {
            '==': true
          }
        }
      }).then(function (tutors) {
        vm.tutors = tutors;
        updateTutors(tutors);
      })
    });

    updateTutors(tutors)
  }
);

'use strict';

angular.module('app.dash').controller('DashCtrl', function ($scope, $window, $ionicPlatform, $ionicPopup, $timeout, PusherInstance, Session, Profile, profile, $ionicModal, $cordovaGeolocation, $ionicLoading, leafletData, geo) {
  var vm = this;

  this.session = Session.createInstance();
  this.map = {
    center: {
      lat: geo.coords.latitude,
      lng: geo.coords.longitude,
      zoom: 17
    },
    controls: {},
    defaults: {
      attributionControl: false
    },
    markers: {
      _user: {
        lat: geo.coords.latitude,
        lng: geo.coords.longitude,
        draggable: false,
        focus: true
      }
    }
  };

  this.navigate = function (label, geo_location) {
    if ($ionicPlatform.is('ios')) {
      $window.open("http://maps.apple.com/?q=" + label + '&ll=' + geo_location.coordinates[0] + ',' + geo_location.coordinates[1], "_system", "location=yes")
    }
  };

  // Remove Leaflet Attribution
  leafletData.getMap('map-canvas').then(function (map) {
    map.attributionControl.removeAttribution('&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors');
    map.attributionControl.setPrefix('');
  });

  // Pusher Events
  PusherInstance.subscribe('session').bind('changed', function (session) {
    if (session.id === vm.session.id) {
      Session.find(session.id, {bypassCache: true}).then(function (session) {
        session.DSLoadRelations(['profile', 'location', 'course']).then(function (session) {
          vm.session = session;
        })
      })
    }
  });

  //
  // this.cancelSession = function () {
  //   $ionicLoading.show();
  //   this.session.DSDestroy().then(function () {
  //     $ionicLoading.hide();
  //     vm.session = Session.createInstance({
  //       student_id: profile.id
  //     });
  //     vm.findTutorModal.hide();
  //     $ionicPopup.alert({
  //       title: "Cancelled",
  //       template: "Tutor Request Cancelled"
  //     })
  //   });
  // };
  //
  // this.setCurrentLocation = function () {
  //   $ionicLoading.show();
  //   $cordovaGeolocation
  //     .getCurrentPosition({timeout: 10000, enableHighAccuracy: true})
  //     .then(function (position) {
  //       $timeout(function () {
  //         $ionicLoading.hide();
  //       }, 500);
  //
  //       vm.map.center = {
  //         lat: position.coords.latitude,
  //         lng: position.coords.longitude,
  //         zoom: 17
  //       };
  //
  //       vm.map.markers.my_location = {
  //         lat: position.coords.latitude,
  //         lng: position.coords.longitude,
  //         draggable: false,
  //         focus: true
  //       };
  //
  //       if (!profile.isAvailable) {
  //         vm.map.markers.my_location.message = vm.tutors.length + ' tutors near you';
  //       }
  //
  //     });
  // };
});

'use strict';

angular.module('app.core', [
    'ionic',
    'ngCordova',
    'nemLogging',
    'ui.router', 'ui-leaflet',
    'js-data',
    'formly', 'formlyIonic',
    'ngMap',
    'ngStamplay',
    'ngMask',
    'angular-storage',
    'angular-stripe',
    'pusher-angular',
    'ionic.rating'
  ])
  .run(function ($rootScope, $stamplay, DS, Config, DSStamplayAdapter, $pusher) {
    // Stamplay.init(Config.ENV.APP_ID);
    DS.registerAdapter('stamplay', DSStamplayAdapter, {default: true});

    // Initialize pusher
    window.client = new Pusher(Config.ENV.PUSHER_KEY);
  })
  .config(function (formlyConfigProvider, DSProvider, DSHttpAdapterProvider, DSStamplayAdapterProvider, Config, stripeProvider) {
    // Configure Stamplay adapter
    DSStamplayAdapterProvider.defaults.appid = Config.ENV.APP_ID;

    // Configure Stripe
    stripeProvider.setPublishableKey(Config.ENV.STRIPE_PUBLISHABLE_KEY);

    // Configure Formly
    formlyConfigProvider.setType({
      name: 'item-divider',
      template: '<ion-item class="item-divider">{{options.templateOptions.label}}</ion-item>'
    });
  });

'use strict';

angular.module('app.core').service('Utilities', function ($document) {
  this.getElementDimensions = function (dom_element) {
    return {
      height: $document[0].getElementsByTagName(dom_element)[0].clientHeight,
      width: $document[0].getElementsByTagName(dom_element)[0].clientWidth
    }
  };

  this.formatSessionTime = function (timestamp) {
    function pad(num) {
      if (num.toString().length === 1) {
        return 0 + '' + num;
      }
      return num;
    }

    var hours, minutes, seconds;

    hours = Math.floor(timestamp / 3600) % 24;
    timestamp -= hours * 3600;
    minutes = Math.floor(timestamp / 60) % 60;
    timestamp -= minutes * 60;
    seconds = timestamp % 60;

    return pad(hours) + ":" + pad(minutes) + ":" + pad(seconds)
  }
});

'use strict';

angular.module('app.core').service('SideMenu', function () {
  var menu = [];

  this.add = function (label, sref, icon, order) {
    menu.push({
      label: label,
      sref: sref,
      icon: icon,
      order: order
    })
  };

  this.addCustom = function () {

  };

  this.getItems = function () {
    return menu;
  }
});

'use strict';

angular.module('app.core').factory('PusherInstance', function ($window, $pusher, Config) {
  var client;

  client = new Pusher(Config.ENV.PUSHER_KEY);

  return $pusher(client);
});

'use strict';

angular.module('app.core').service('Auth', function ($stamplay) {
  this.login = function (credentials) {
    return $stamplay.User.login(credentials);
  };

  this.signup = function (credentials) {
    return $stamplay.User.signup(credentials);
  };
});

'use strict';

angular.module('app.core')
  .service('User', function (DS, DSStamplayAdapter) {
    return DS.defineResource({
      name: 'user',

      // Static methods
      login: function (credentials) {
        return DSStamplayAdapter.login(credentials);
      },
      register: function (credentials) {
        return DSStamplayAdapter.register(credentials);
      },
      logout: function () {
        return DSStamplayAdapter.logout();
      },
      currentUser: function () {
        return DSStamplayAdapter.currentUser();
      }
    });
  }).run(function (User) {
});

'use strict';

angular.module('app.core').service('Transcript', function (DS) {
  return DS.defineResource({
    name: 'transcript'
  })
}).run(function (Transcript) {
});

'use strict';

angular.module('app.core')
  .service('Session', function (DS) {
    return DS.defineResource({
      name: 'session',
      relations: {
        hasOne: {
          profile: [{
            localField: 'student',
            localKey: 'student_id'
          }, {
            localField: 'tutor',
            localKey: 'tutor_id'
          }],
          location: {
            localField: 'location',
            localKey: 'location_id'
          },
          course: {
            localField: 'course',
            localKey: 'course_id'
          }
        }
      }
    })
  }).run(function (Session) {
});

'use strict';

angular.module('app.core').service('School', function (DS) {
  return DS.defineResource({
    name: 'school'
  });
}).run(function (School) {
});

'use strict';

angular.module('app.core')
  .service('Profile', function (DS, DSStamplayAdapter) {
    return DS.defineResource({
      name: 'profile',
      updateProfilePicture: function (file) {
        return DSStamplayAdapter.uploadFile(this, {profile_image: file});
      },
      getCard: function (user) {
        return DSStamplayAdapter.getCreditCard(user);
      },
      relations: {
        hasOne: {
          school: {
            localField: 'school',
            localKey: 'school_id'
          },
          user: {
            localField: 'user',
            localKey: 'user_id'
          }
        }
      },
      computed: {
        fullName: ['first_name', 'last_name', function (first_name, last_name) {
          return first_name + ' ' + last_name;
        }]
      }
    })
      ;
  }).run(function (Profile) {
});


'use strict';

angular.module('app.core')
  .service('Payment', function (DS, DSStamplayAdapter) {
    return DS.defineResource({
      name: 'Payment',
      getCreditCard: function (user_id) {
        return DSStamplayAdapter.getCreditCard(user_id);
      },
      charge: function (user_id, token, amount, currency) {
        return DSStamplayAdapter.charge(user_id, token, amount, currency);
      }
    })
  }).run(function (Payment) {
});

'use strict';

angular.module('app.core')
  .service('Location', function (DS) {
    return DS.defineResource({
      name: 'location',
      relations: {
        hasOne: {
          school: {
            localField: 'school',
            localKey: 'school_id'
          }
        }
      }
    })
  }).run(function (Location) {
});

'use strict';

angular.module('app.core')
  .service('Course', function (DS) {
    return DS.defineResource({
      name: 'course'
    })
  }).run(function (Course) {
});

'use strict';

angular.module('app.core').provider('DSStamplayAdapter', function DSStamplayAdapterProvider(DSProvider) {
  DSProvider.defaults = {
    idAttribute: '_id'
  };

  this.defaults = {};

  /**
   * Converts `hasOne` relations from a one element array to a direct reference
   * @param objects
   * @param relations
   * @returns {*}
   */
  function convertRelations(objects, relations) {
    objects = _.isArray(objects) ? objects : [objects];

    _.forEach(relations, function (relation) {
      if (relation.type === 'hasOne') {
        // Convert all hasOne relations to direct references
        _.forEach(objects, function (result) {
          if (_.isArray(result[relation.localKey])) {
            result[relation.localKey] = result[relation.localKey][0];
          }
        })
      }
    });

    return objects;
  }

  function DSStamplayAdapter(defaults, service, q, store, config, upload) {
    this.defaults = defaults;
    this.upload = upload;
    this.lib = Stamplay;
    this.service = service;
    this.q = q;
    this.store = store;
    this.config = config;

    this.defaults.basePath = Stamplay.BASEURL;
    this.lib.init(defaults.appid);
  }

  // Stripe
  DSStamplayAdapter.prototype.createCustomer = function (user_id) {
    return this.service.Stripe.createCustomer(user_id);
  };
  DSStamplayAdapter.prototype.createCreditCard = function (user_id, token) {
    return this.service.Stripe.createCreditCard(user_id, token);
  };
  DSStamplayAdapter.prototype.getCreditCard = function (user_id) {
    return this.service.Stripe.getCreditCard(user_id);
  };
  DSStamplayAdapter.prototype.updateCreditCard = function (user_id, token) {
    return this.service.Stripe.updateCreditCard(user_id, token);
  };
  DSStamplayAdapter.prototype.charge = function (user_id, token, amount, currency) {
    return this.service.Stripe.charge(user_id, token, amount, currency);
  };


  DSStamplayAdapter.prototype.uploadFile = function (resourceConfig, file) {
    var deferred = this.q.defer();

    this.upload.upload({
      url: this.defaults.basePath + '/api/cobject' + this.config.ENV.API_VERSION + resourceConfig.endpoint,
      data: file
    }).then(function (response) {
      debugger;
      deferred.resolve(response);
    }).catch(function (error) {
      debugger;
      deferred.reject(error);
    });

    return deferred.promise;
  };
  DSStamplayAdapter.prototype.logout = function () {
    var deferred = this.q.defer();

    this.store.remove(window.location.origin + '-jwt');

    deferred.resolve();

    return deferred.promise;
  };

  DSStamplayAdapter.prototype.login = function (credentials) {
    return this.service.User.login(credentials);
  };

  DSStamplayAdapter.prototype.currentUser = function () {
    var deferred = this.q.defer();

    this.service.User.currentUser().then(function (user) {
      deferred.resolve(user.user);
    }).catch(function (error) {
      deferred.reject(error);
    });

    return deferred.promise;
  };

  DSStamplayAdapter.prototype.register = function (credentials) {
    return this.service.User.signup(credentials);
  };

  DSStamplayAdapter.prototype.getLib = function () {
    return this.lib;
  };

  DSStamplayAdapter.prototype.getService = function () {
    return this.service;
  };

  // Objects
  DSStamplayAdapter.prototype.find = function (resourceConfig, id, options) {
    var deferred = this.q.defer();

    if (resourceConfig.name === 'user') {
      return this.currentUser();
    } else {
      this.service.Object(resourceConfig.endpoint).get({_id: id}).then(function (data) {
        deferred.resolve(convertRelations(data.data, resourceConfig.relationList)[0]);
      }).catch(function (error) {
        debugger;
        deferred.reject(error);
      });
    }

    return deferred.promise;
  };
  DSStamplayAdapter.prototype.findAll = function (resourceConfig, params, options) {
    var deferred = this.q.defer();

    if (resourceConfig.name === 'user') {
      this.currentUser().then(function (user) {
        deferred.resolve([user]);
      })
    } else if (_.isObject(params)) {
      var query = this.service.Query('object', resourceConfig.endpoint);

      for (var verb in params) {
        if (params.hasOwnProperty(verb)) {
          for (var param in params[verb]) {
            if (params[verb].hasOwnProperty(param)) {
              // Where clause
              if (verb === 'where') {
                if (!_.isUndefined(params[verb][param]['=='])) {
                  query = query.equalTo(param, params[verb][param]['==']);
                }
              } else if (verb === 'orderBy') {

              } else if (verb === 'offset') {

              } else if (verb === 'limit') {

              }
            }
          }
        }
      }

      // Execute the query
      query.exec().then(function (results) {
        deferred.resolve(convertRelations(results.data, resourceConfig.relationList));
      }).catch(function (error) {
        deferred.reject(error);
      })
    } else {
      this.service.Object(resourceConfig.endpoint).get(params).then(function (response) {
        deferred.resolve(convertRelations(response.data, resourceConfig.relationList));
      }).catch(function (error) {
        deferred.reject(error);
      });
    }

    return deferred.promise;
  };
  DSStamplayAdapter.prototype.create = function (resourceConfig, params, options) {
    var deferred = this.q.defer();

    this.service.Object(resourceConfig.endpoint).save(params).then(function (response) {
      deferred.resolve(convertRelations(response, resourceConfig.relationList)[0]);
    }).catch(function (error) {
      deferred.reject(error);
    });

    return deferred.promise;
  };
  DSStamplayAdapter.prototype.update = function (resourceConfig, id, attrs, options) {
    var deferred = this.q.defer();

    this.service.Object(resourceConfig.endpoint).update(id, attrs).then(function (response) {
      deferred.resolve(convertRelations(response, resourceConfig.relationList)[0]);
    }).catch(function (error) {
      deferred.reject(error);
    });

    return deferred.promise;
  };
  DSStamplayAdapter.prototype.destroy = function (resourceConfig, id, options) {
    var deferred = this.q.defer();

    this.service.Object(resourceConfig.endpoint).remove(id).then(function (data) {
      deferred.resolve(data);
    }).catch(function (error) {
      deferred.reject(error);
    });

    return deferred.promise;
  };

  this.$get = function ($stamplay, $q, store, Config, Upload) {
    return new DSStamplayAdapter(this.defaults, $stamplay, $q, store, Config, Upload);
  }
})
;

'use strict';

angular.module('app.core').value('RegisterFields',
  [{
    key: "divider",
    type: "item-divider",
    templateOptions: {
      type: "text",
      label: "Your Information",
      placeholder: "First Name",
      required: true
    }
  }, {
    key: 'profile.first_name',
    type: 'input',
    templateOptions: {
      type: 'text',
      required: true,
      placeholder: 'First Name',
      icon: 'ion-ios-person',
      iconPlaceholder: true
    }
  }, {
    key: 'profile.last_name',
    type: 'input',
    templateOptions: {
      type: 'text',
      label: 'Last Name',
      required: true,
      placeholder: 'Last Name',
      icon: 'ion-ios-person',
      iconPlaceholder: true
    }
  }, {
    key: 'profile.phone_number',
    type: 'input',
    templateOptions: {
      type: 'text',
      required: true,
      placeholder: 'Phone number',
      icon: 'ion-ios-telephone',
      iconPlaceholder: true
    }
  }, {
    key: 'profile.school_id',
    type: 'select',
    templateOptions: {
      label: "Select School",
      options: [],
      valueProp: '_id',
      labelProp: 'name'
    },
    controller: function ($scope, DS) {
      DS.findAll('school').then(function (schools) {
        $scope.to.options = schools;
      });
    }
  }, {
    key: "divider",
    type: "item-divider",
    templateOptions: {
      type: "text",
      label: "Account Information",
      placeholder: "First Name"
    }
  }, {
    key: 'credentials.email',
    type: 'input',
    templateOptions: {
      type: 'text',
      required: true,
      placeholder: 'Email',
      icon: 'ion-ios-email',
      iconPlaceholder: true
    }
  }, {
    key: 'credentials.password',
    type: 'input',
    templateOptions: {
      type: 'password',
      required: true,
      placeholder: 'Password',
      icon: 'ion-locked',
      iconPlaceholder: true
    }
  }, {
    key: 'confirmPassword',
    type: 'input',
    templateOptions: {
      type: 'password',
      placeholder: 'Confirm password',
      required: true,
      icon: 'ion-locked',
      iconPlaceholder: true
    },
    extras: {
      validateOnModelChange: true
    },
    validators: {
      confirmPassword: {
        expression: function (viewValue, modelValue, fieldScope) {
          if (!_.isUndefined(fieldScope.model.credentials) && !_.isUndefined(fieldScope.model.credentials.password)) {
            return modelValue === fieldScope.model.credentials.password;
          }
        },
        message: "Passwords do not match'"
      }
    }
  }]
);

'use strict';

angular.module('app.core').value('LoginFields',
  [
    {
      key: 'email',
      type: 'input',
      templateOptions: {
        type: 'text',
        label: 'Email Address',
        required: true,
        placeholder: 'Email Address'
      }
    },
    {
      key: 'password',
      type: 'input',
      templateOptions: {
        type: 'password',
        label: 'Password',
        required: true,
        placeholder: 'Password'
      }
    }
  ]
);

'use strict';

angular.module('app.core').config(function ($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('/core/main');

  $stateProvider
    .state('core', {
      url: '/core',
      abstract: true,
      templateUrl: 'core/views/layouts/core.html',
      controller: 'CoreCtrl as core'
    })
    .state('app', {
      url: '/app',
      abstract: true,
      templateUrl: 'core/views/layouts/app.html',
      controller: 'AppCtrl as app',
      resolve: {
        geo: function ($cordovaGeolocation) {
          return $cordovaGeolocation.getCurrentPosition({timeout: 10000, enableHighAccuracy: true});
        },
        user: function (User) {
          return User.currentUser();
        },
        schools: function (School) {
          return School.findAll();
        },
        profile: function (Profile, user) {
          return Profile.findAll({
            where: {
              user_id: {
                '==': user.id
              }
            }
          }).then(function (profile) {
            return profile[0].DSLoadRelations(['school', 'user']);
          });
        }
      }
    })
    .state('core.main', {
      url: '/main',
      templateUrl: 'core/views/main.html',
      controller: 'MainCtrl as main'
    });
});

'use strict';

angular.module('app.core').controller('MainCtrl', function ($scope) {
  this.options = {
    slides: {}
  }
});

'use strict';

angular.module('app.core').controller('CoreCtrl', function ($scope, $stamplay, store, $state, $ionicLoading, $ionicModal, Auth, RegisterFields, $ionicPopup, LoginFields, DS) {
  this.fields = {
    register: RegisterFields,
    login: LoginFields
  };

  this.register = function (registration) {
    $ionicLoading.show();

    DS.definitions.user.register(registration.credentials).then(function (user) {
      registration.profile.user_id = user.id;
      DS.create('profile', registration.profile).then(function (profile) {
        $ionicLoading.hide();
        $state.go('app.dash');
        $scope.modal.hide();
      })
    }).catch(function (error) {
      $ionicLoading.hide();
      $ionicPopup.alert({
        title: 'Registration Error',
        template: error.message
      })
    });
  };

  this.login = function (credentials) {
    $ionicLoading.show();
    DS.definitions.user.login(credentials).then(function () {
      $ionicLoading.hide();
      $state.go('app.dash.student');
      $scope.modal.hide();
    }).catch(function (error) {
      $ionicLoading.hide();
      $ionicPopup.alert({
        title: "Login Error",
        template: error.message
      })
    });
  };

  this.showAuthModal = function (page) {
    $ionicModal.fromTemplateUrl('core/views/modals/' + page + '.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function (modal) {
      $scope.modal = modal;
      modal.show();
    });
  };

  $scope.hideModal = function () {
    $scope.modal.hide().then(function () {
      $state.go('app.dash');
    })
  };
});

'use strict';

angular.module('app.core').controller('AppCtrl', function ($q, $rootScope, $state, $interval, $ionicPopup, Config, $cordovaGeolocation, SideMenu, $timeout, $ionicLoading, $ionicHistory, DS, profile, geo) {
  var vm = this;

  this.sideMenuItems = SideMenu.getItems();
  this.profile = profile;
  this.state = $state;
  this._tutorLocationUpdaterTimer = undefined;

  function _updateLocation() {
    var deferred = $q.defer();

    $cordovaGeolocation
      .getCurrentPosition({timeout: 10000, enableHighAccuracy: true})
      .then(function (position) {
        profile._geolocation = {
          type: 'Point',
          coordinates: [position.coords.longitude, position.coords.latitude]
        };

        profile.DSSave().then(function () {
          deferred.resolve();
        })
      });

    return deferred.promise;
  }

  $rootScope.$on('location:update', function () {
    _updateLocation()
  });

  $rootScope.$on('availability:toggle', function () {
    _updateLocation().then(function () {
      $ionicLoading.hide();
    })
  });

  $interval(function () {
    console.log("updating...");
    $rootScope.$broadcast('location:update');
  }, 5000);


  this.logout = function () {
    $ionicLoading.show();
    DS.definitions.user.logout().then(function () {
      $ionicHistory.clearCache();
      $ionicLoading.hide();
      $state.go('core.main');
    });
  };

  this.becomeATutor = function () {
    $ionicPopup.alert({
      title: 'Sending Transcript',
      template: 'Official transcripts are required in order to tutor other students. Please send official transcripts to the address below<br/><br/>' + Config.ENV.PHYSICAL_ADDRESS
    });
  };

  this.toggleAvailability = function () {
    var message = this.profile.isAvailable ? 'Turning ON tutor mode...' : 'Turning OFF tutor mode...';
    $ionicLoading.show({template: message});

    $rootScope.$broadcast('availability:toggle');
  };

  this.openDashboard = function (state) {
    $state.go(state);
  }
});

'use strict';

angular.module('app.core').value('ENUM', {
  SESSION: {
    PENDING: 0,
    AWAITING_HAND_SHAKE: 1,
    PENDING_START: 2,
    IN_PROGRESS: 3,
    FINISHED: 4
  }
});

'use strict';
angular.module('app.core').constant('Config', {
  // gulp environment: injects environment vars
  ENV: {
    /*inject-env*/
    'DB_URL': 'https://pupilapp.firebaseio.com',
    'APP_ID': 'pupil',
    'BASEPATH': 'https://pupil.stamplayapp.com/',
    'API_VERSION': '/v1/',
    'STRIPE_PUBLISHABLE_KEY': 'pk_test_YN0sziTqFTY2jtL3EJGlD0qD',
    'PUSHER_KEY': '654197fc1a675095ac1f',
    'PHYSICAL_ADDRESS': '<strong>Pupil Labs</strong><br/> 2870 Peachtree Rd #915-2829<br/> Atlanta, GA 30305'
    /*endinject*/
  },

  // gulp build-vars: injects build vars
  BUILD: {
    /*inject-build*/
    /*endinject*/
  }
});

'use strict';

angular.module('app.classes', ['app.core'])
  .run(function () {

  });

'use strict';

angular.module('app.classes').controller('ClassesCtrl', function (courses) {
  this.courses = courses;
});

'use strict';

angular.module('app.classes').config(function ($stateProvider) {
  $stateProvider
    .state('app.classes', {
      url: '/classes',
      views: {
        pageContent: {
          templateUrl: '/classes/views/classes.html',
          controller: 'ClassesCtrl as classes',
          resolve: {
            courses: function (Course) {
              return Course.findAll();
            }
          }
        }
      }
    })
});

'use strict';
angular.module('Pupil', [
  'app.core',
  'app.profile',
  'app.dash',
  'app.payment',
  'app.session',
  'app.classes',
  'app.transcripts'
]);
