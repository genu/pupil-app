'use strict';

angular.module('app.core').controller('MainCtrl', function ($scope) {
  this.options = {
    slides: {}
  }
});
