'use strict';

angular.module('app.classes').controller('ClassesCtrl', function (courses) {
  this.courses = courses;
});
