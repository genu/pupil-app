'use strict';

angular.module('app.classes', ['app.core'])
  .run(function () {

  });
