'use strict';
angular.module('Pupil', [
  'app.core',
  'app.profile',
  'app.dash',
  'app.payment',
  'app.session',
  'app.classes',
  'app.transcripts'
]);
