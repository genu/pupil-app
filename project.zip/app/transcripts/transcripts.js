'use strict';

angular.module('app.transcripts', ['app.core', 'ngFileUpload'])
  .run(function () {

  });
